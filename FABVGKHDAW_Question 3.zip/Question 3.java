import java.util.HashSet;
import java.util.Scanner;

public class Main {
    public boolean isThereASum(int[] arr, int t) {
        HashSet<Integer> set = new HashSet<>();
        for (int num : arr) {
            if (set.contains(t - num)) {
                return true;
            }
            set.add(num);
        }
        return false;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        int t = scanner.nextInt();
        
        Main main = new Main();
        boolean result = main.isThereASum(arr, t);
        System.out.println( result);
        
        scanner.close();
    }
}